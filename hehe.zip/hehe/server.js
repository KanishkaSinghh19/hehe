const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Save user responses
app.post('/saveResponses', (req, res) => {
  const userResponses = req.body;

  // Save responses into a file
  fs.appendFile('responses.json', JSON.stringify(userResponses) + '\n', (err) => {
    if (err) {
      console.error('Error saving responses:', err);
      res.status(500).json({ message: 'Error saving responses' });
    } else {
      res.status(200).json({ message: 'Responses saved successfully!' });
    }
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
